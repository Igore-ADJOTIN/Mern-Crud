This is a Mern stack project.
Do `npm install` on frontend and backend
Then `npm Run dev`  on  frontend and backend.
AND enjoy

Igore ADJOTIN