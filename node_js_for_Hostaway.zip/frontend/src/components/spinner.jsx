import React from 'react'

const Spinner = () => {
  return (
    <div className='animate-ping w-16 text-center h-16 m-8 bg-sky-600 rounded-full'></div>
  )
}

export default Spinner