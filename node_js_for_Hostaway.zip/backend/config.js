export const PORT = 5555;
export const mongoDBURL = 'mongodb+srv://root:root@cluster0.ennxwnf.mongodb.net/book_collections?retryWrites=true&w=majority&appName=Cluster0'